Greetings sir,

I have uploaded The pre-trained CNN model with 93% accuracy.
Please load the model and save it.

The project report and Python file have also been attached.
